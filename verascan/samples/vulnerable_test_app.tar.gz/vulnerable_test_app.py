#!/usr/bin/env python3
"""
Vulnerable Python application for security testing purposes.
WARNING: This code contains intentional vulnerabilities for testing only.
DO NOT USE IN PRODUCTION.
"""

import os
import subprocess
import sqlite3
from flask import Flask, request, render_template_string

app = Flask(__name__)

# Vulnerable: SQL Injection
def get_user_data(user_id):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    # Vulnerable: Direct string concatenation allows SQL injection
    query = f"SELECT * FROM users WHERE id = {user_id}"
    cursor.execute(query)
    result = cursor.fetchall()
    conn.close()
    return result

# Vulnerable: Command Injection
def ping_host():
    # Get hostname from environment variable without validation
    hostname = os.environ.get('TARGET_HOST', 'localhost')
    # Vulnerable: Direct command execution without sanitization
    command = f"ping -c 1 {hostname}"
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return result.stdout

# Vulnerable: Template Injection
@app.route('/greet')
def greet():
    name = request.args.get('name', 'World')
    # Vulnerable: Direct template rendering allows SSTI
    template = f"Hello {name}!"
    return render_template_string(template)

# Vulnerable: Path Traversal
@app.route('/read_file')
def read_file():
    filename = request.args.get('file', 'default.txt')
    # Vulnerable: No path validation allows directory traversal
    try:
        with open(filename, 'r') as f:
            content = f.read()
        return content
    except Exception as e:
        return str(e)

# Vulnerable: Hardcoded credentials
DATABASE_PASSWORD = "admin123"
SECRET_KEY = "supersecret123"

# Vulnerable: Insecure deserialization
import pickle
import base64

@app.route('/deserialize')
def deserialize_data():
    data = request.args.get('data')
    if data:
        try:
            # Vulnerable: Deserializing untrusted data
            decoded = base64.b64decode(data)
            obj = pickle.loads(decoded)
            return str(obj)
        except:
            return "Invalid data"
    return "No data provided"

if __name__ == '__main__':
    # Initialize database
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS users 
                     (id INTEGER PRIMARY KEY, name TEXT, email TEXT)''')
    cursor.execute("INSERT OR IGNORE INTO users VALUES (1, 'admin', 'admin@example.com')")
    cursor.execute("INSERT OR IGNORE INTO users VALUES (2, 'user', 'user@example.com')")
    conn.commit()
    conn.close()
    
    print("Starting vulnerable test application...")
    print("Environment variables:")
    print(f"TARGET_HOST: {os.environ.get('TARGET_HOST', 'Not set')}")
    
    # Run the ping test
    print("\nTesting ping functionality:")
    print(ping_host())
    
    # Vulnerable: Debug mode enabled in production
    app.run(host='0.0.0.0', port=5000, debug=True)